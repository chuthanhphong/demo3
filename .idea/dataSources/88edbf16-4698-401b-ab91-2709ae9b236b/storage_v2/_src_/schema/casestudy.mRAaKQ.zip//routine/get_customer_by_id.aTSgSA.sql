create
    definer = root@localhost procedure get_customer_by_id(IN id int)
begin
    select * from customers where customerID = id;
end;

