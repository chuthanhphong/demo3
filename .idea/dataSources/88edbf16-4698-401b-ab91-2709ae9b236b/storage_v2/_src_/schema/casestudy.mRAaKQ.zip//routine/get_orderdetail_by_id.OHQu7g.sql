create
    definer = root@localhost procedure get_orderdetail_by_id(IN id int)
begin
    select * from orderdetail where orderId = id;
end;

