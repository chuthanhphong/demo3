create
    definer = root@localhost procedure update_customer(IN id int, IN name varchar(50), IN phone int,
                                                       IN email varchar(50), IN address varchar(50),
                                                       IN cUserName varchar(50), IN cPassword varchar(50))
begin
    update customers
        set customerName = name,customerPhone = phone,customerEmail = email,customerAddress = address,userName = cUserName,password = cPassword
    where customerID = id;
end;

