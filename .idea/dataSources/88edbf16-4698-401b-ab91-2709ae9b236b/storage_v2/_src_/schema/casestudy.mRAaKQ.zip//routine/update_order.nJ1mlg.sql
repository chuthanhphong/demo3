create
    definer = root@localhost procedure update_order(IN id int, IN customerid1 int, IN orderDate1 date,
                                                    IN isShipped1 tinyint(1))
begin
    update orders
        set customerID = customerid1,orderDate = orderDate1,isShipped = isShipped1
        where orderID = id;
end;

