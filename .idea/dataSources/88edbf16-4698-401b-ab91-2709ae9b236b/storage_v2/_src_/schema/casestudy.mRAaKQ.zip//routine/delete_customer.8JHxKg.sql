create
    definer = root@localhost procedure delete_customer(IN id int)
begin
    delete from customers where customerID = id;
end;

